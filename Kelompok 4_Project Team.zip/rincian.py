import csv
from tkinter import Tk, Label
from pathlib import Path
from PIL import Image, ImageTk

def generate_nota():
    nota_text = "Nota Pembelian\n\n"
    total = 0

    try:
        with open('order_makan.csv', newline='') as csvfile:
            reader = csv.reader(csvfile)
            next(reader)  # Skip header row if any
            nota_text += "Makanan:\n"
            for row in reader:
                menu, jumlah, harga = row
                subtotal = float(jumlah) * float(harga)
                nota_text += f"{menu}: {jumlah} x Rp{harga} = Rp{subtotal:.2f}\n"
                total += subtotal
    except FileNotFoundError:
        nota_text += "Makanan: Tidak ada data.\n"

    try:
        with open('order_minum.csv', newline='') as csvfile:
            reader = csv.reader(csvfile)
            next(reader)  # Skip header row if any
            nota_text += "\nMinuman:\n"
            for row in reader:
                menu, jumlah, harga = row
                subtotal = float(jumlah) * float(harga)
                nota_text += f"{menu}: {jumlah} x Rp{harga} = Rp{subtotal:.2f}\n"
                total += subtotal
    except FileNotFoundError:
        nota_text += "Minuman: Tidak ada data.\n"

    nota_text += f"\nTotal: Rp{total:.2f}\n"
    return nota_text

def create_nota_gui():
    # Create GUI window
    window = Tk()
    window.title("Nota Pembelian")
    window.geometry('600x400')
    window.configure(bg="#fbcd64")

    # Generate nota text
    nota_text = generate_nota()

    # Create label for nota
    nota_label = Label(window, text=nota_text, font=("Helvetica", 12), bg="#fbcd64")
    nota_label.pack(pady=20)

    # Run GUI loop
    window.mainloop()

create_nota_gui()
