import csv
from tkinter import ttk
from pathlib import Path
import customtkinter as ctk
from PIL import Image, ImageTk
import openpyxl
import subprocess

OUTPUT_PATH = Path(__file__).parent
ASSETS_PATH = OUTPUT_PATH / Path(r"D:\SELF ORDER MACHINE\assets")

def metode():
    window6 = ctk.CTkToplevel()
    window6.title("WARPAT!")
    window6.geometry('1920x1200')
    window6.state('zoomed')
    window6.configure(bg="#fbcd64")
    window6.resizable(True, True)

    bg_welcome = ImageTk.PhotoImage(Image.open("assets/background_metode.png"))
    bgr = ctk.CTkLabel(master=window6, image=bg_welcome, text="")
    bgr.pack()

    def button_metode(path: str) -> Path:
        return ASSETS_PATH / Path(path)

    button_tunai = ctk.CTkImage(Image.open(button_metode("button_tunai.png")), size=(307.36, 214.87))
    button_4 = ctk.CTkButton(
        window6,
        image=button_tunai,
        border_width=0,
        corner_radius=0,
        bg_color="#fbcd64",
        fg_color="#fbcd64",
        hover_color="#fbcd64",
        command=lambda: [],
        text=''
    )
    button_4.place(x=150.0, y=250.0)

    def show_qris():
        popup = ctk.CTkToplevel(window6)
        popup.title("QRIS")
        popup.geometry('400x600')
        popup.configure(bg="#fbcd64")

        qris_img = ImageTk.PhotoImage(Image.open("assets/qris.jpg"))
        qris_label = ctk.CTkLabel(popup, image=qris_img, text="")
        qris_label.image = qris_img  # To keep a reference
        qris_label.pack(pady=20)

        button_selesai_img = ctk.CTkImage(Image.open(button_metode("button_selesai.png")), size=(180, 53.97))
        button_selesai = ctk.CTkButton(
            popup,
            image=button_selesai_img,
            border_width=0,
            corner_radius=0,
            bg_color="#fbcd64",
            fg_color="#fbcd64",
            hover_color="#fbcd64",
            command=lambda: [popup.destroy(), window6.destroy(), display_nota()],
            text=''
        )
        button_selesai.pack(pady=20)

    button_qris = ctk.CTkImage(Image.open(button_metode("button_qris.png")), size=(307.36, 214.87))
    button_4 = ctk.CTkButton(
        window6,
        image=button_qris,
        border_width=0,
        corner_radius=0,
        bg_color="#fbcd64",
        fg_color="#fbcd64",
        hover_color="#fbcd64",
        command=show_qris,
        text=''
    )
    button_4.place(x=500.0, y=250.0)

    button_transfer = ctk.CTkImage(Image.open(button_metode("button_transfer.png")), size=(307.36, 214.87))
    button_4 = ctk.CTkButton(
        window6,
        image=button_transfer,
        border_width=0,
        corner_radius=0,
        bg_color="#fbcd64",
        fg_color="#fbcd64",
        hover_color="#fbcd64",
        command=lambda: [],
        text=''
    )
    button_4.place(x=850.0, y=250.0)

def generate_nota():
    nota_text = "Nota Pembelian\n\n"
    total = 0

    try:
        with open('order_makan.csv', newline='') as csvfile:
            reader = csv.reader(csvfile)
            next(reader)  # Skip header row if any
            nota_text += "Makanan:\n"
            for row in reader:
                item, price = row
                nota_text += f"{item}: {price}\n"
                total += float(price)
    except FileNotFoundError:
        nota_text += "Makanan: Tidak ada data.\n"

    try:
        with open('order_minum.csv', newline='') as csvfile:
            reader = csv.reader(csvfile)
            next(reader)  # Skip header row if any
            nota_text += "\nMinuman:\n"
            for row in reader:
                item, price = row
                nota_text += f"{item}: {price}\n"
                total += float(price)
    except FileNotFoundError:
        nota_text += "Minuman: Tidak ada data.\n"

    nota_text += f"\nTotal: {total}\n"
    return nota_text

def display_nota():
    window7 = ctk.CTkToplevel()
    window7.title("Nota")
    window7.geometry('1920x1200')
    window7.state('zoomed')
    window7.configure(bg="#fbcd64")
    window7.resizable(True, True)

    nota = generate_nota()
    nota_label = ctk.CTkLabel(window7, text=nota, font=("Helvetica", 16), text_color="#000000", width=1000, height=500, bg_color="#FFFFFF")
    nota_label.place(relx=0.5, rely=0.5, anchor='center')
    nota_label.lift()

def rincian():
    window5 = ctk.CTkToplevel()
    window5.title("WARPAT!")
    window5.geometry('1920x1200')
    window5.state('zoomed')
    window5.configure(bg="#fbcd64")
    window5.resizable(True, True)

    bg_welcome = ImageTk.PhotoImage(Image.open("assets/background_rincian.png"))
    bgr = ctk.CTkLabel(master=window5, image=bg_welcome, text="")
    bgr.pack()

    def button_rinci(path: str) -> Path:
        return ASSETS_PATH / Path(path)

    button_rincian = ctk.CTkImage(Image.open(button_rinci("button_rincian.png")), size=(247.29, 53.97))
    button_6 = ctk.CTkButton(
        window5,
        image=button_rincian,
        border_width=0,
        corner_radius=0,
        bg_color="#48775D",
        fg_color="#48775D",
        hover_color="#48775D",
        command=lambda: subprocess.run(['python', 'rincian.py']),  # Pemanggilan rincian.py di sini
        text=''
    )
    button_6.place(x=0.0, y=665.0)

    button_lanjut = ctk.CTkImage(Image.open(button_rinci("button_lanjut.png")), size=(247.29, 53.97))
    button_7 = ctk.CTkButton(
        window5,
        image=button_lanjut,
        border_width=0,
        corner_radius=0,
        bg_color="#48775D",
        fg_color="#48775D",
        hover_color="#48775D",
        command=lambda: [window5.destroy(), metode()],
        text=''
    )
    button_7.place(x=1050.0, y=665.0)

def menu_list():
    window4 = ctk.CTkToplevel()
    window4.title("WARPAT!")
    window4.geometry('1920x1200')
    window4.state('zoomed')
    window4.configure(bg="#fbcd64")
    window4.resizable(True, True)

    bg_welcome = ImageTk.PhotoImage(Image.open("assets/background_menu.png"))
    bgr = ctk.CTkLabel(master=window4, image=bg_welcome, text="")
    bgr.pack()

    def button_dine(path: str) -> Path:
        return ASSETS_PATH / Path(path)

    button_makanan = ctk.CTkImage(Image.open(button_dine("button_makanan.png")), size=(307.36, 214.87))
    button_4 = ctk.CTkButton(
        window4,
        image=button_makanan,
        border_width=0,
        corner_radius=0,
        bg_color="#fbcd64",
        fg_color="#fbcd64",
        hover_color="#fbcd64",
        command=lambda: [subprocess.run(['python', 'list_makanan.py'])],
        text=''
    )
    button_4.place(x=310.0, y=250.0)

    button_minuman = ctk.CTkImage(Image.open(button_dine("button_minuman.png")), size=(307.36, 214.87))
    button_5 = ctk.CTkButton(
        window4,
        image=button_minuman,
        border_width=0,
        corner_radius=0,
        bg_color="#fbcd64",
        fg_color="#fbcd64",
        hover_color="#fbcd64",
        command=lambda: [subprocess.run(['python', 'list_minuman.py'])],
        text=''
    )
    button_5.place(x=650.0, y=250.0)

    button_rincian = ctk.CTkImage(Image.open(button_dine("button_rincian.png")), size=(247.29, 53.97))
    button_6 = ctk.CTkButton(
        window4,
        image=button_rincian,
        border_width=0,
        corner_radius=0,
        bg_color="#48775D",
        fg_color="#48775D",
        hover_color="#48775D",
        command=lambda: [window4.destroy(), rincian()],
        text=''
    )
    button_6.place(x=1000.0, y=665.0)

def dine_option():
    window3 = ctk.CTkToplevel()
    window3.title("WARPAT!")
    window3.geometry('1920x1200')
    window3.state('zoomed')
    window3.configure(bg="#fbcd64")
    window3.resizable(True, True)

    bg_welcome = ImageTk.PhotoImage(Image.open("assets/background_saji.png"))
    bgr = ctk.CTkLabel(master=window3, image=bg_welcome, text="")
    bgr.pack()

    def button_dine(path: str) -> Path:
        return ASSETS_PATH / Path(path)

    button_makansini = ctk.CTkImage(Image.open(button_dine("button_makansini.png")), size=(307.36, 214.87))
    button_3 = ctk.CTkButton(
        window3,
        image=button_makansini,
        border_width=0,
        corner_radius=0,
        bg_color="#fbcd64",
        fg_color="#fbcd64",
        hover_color="#fbcd64",
        command=lambda: [window3.destroy(), menu_list()],
        text=''
    )
    button_3.place(x=310.0, y=250.0)

    button_bungkus = ctk.CTkImage(Image.open(button_dine("button_bungkus.png")), size=(307.36, 214.87))
    button_4 = ctk.CTkButton(
        window3,
        image=button_bungkus,
        border_width=0,
        corner_radius=0,
        bg_color="#fbcd64",
        fg_color="#fbcd64",
        hover_color="#fbcd64",
        command=lambda: [window3.destroy(), menu_list()],
        text=''
    )
    button_4.place(x=650.0, y=250.0)

    window3.mainloop()

def halaman_nama():
    def save_to_excel(nama):
        file_path = "id_nama.xlsx"
        try:
            workbook = openpyxl.load_workbook(file_path)
            sheet = workbook.active
        except FileNotFoundError:
            workbook = openpyxl.Workbook()
            sheet = workbook.active
            sheet['A1'] = 'Nama'

        next_row = sheet.max_row + 1
        sheet[f'A{next_row}'] = nama

        workbook.save(file_path)

    def on_button_click():
        nama = entry_nama.get()
        if nama:  
            save_to_excel(nama)
            window2.destroy()
            dine_option()  

    window2 = ctk.CTkToplevel()
    window2.title("WARPAT!")
    window2.geometry('1920x1200')
    window2.state('zoomed')
    window2.configure(bg="#fbcd64")
    window2.resizable(True, True)

    bg_welcome = ImageTk.PhotoImage(Image.open("assets/background_nama.png"))
    bgr = ctk.CTkLabel(master=window2, image=bg_welcome, text="")
    bgr.pack()

    entry_nama = ctk.CTkEntry(
        window2,
        placeholder_text="Masukkan Nama Anda",
        height=58.1,
        width=791,
        font=("Helvetica", 18),
        corner_radius=15,
        text_color='#FFFFFF',
        placeholder_text_color="#C7411E",
        fg_color=("#F28743"),
        bg_color="#fbcd64",
        border_width=3,
        border_color=('#C7411E')
    )
    entry_nama.place(x=240, y=350)

    def button_nama(path: str) -> Path:
        return ASSETS_PATH / Path(path)

    button_masuk_img = ctk.CTkImage(Image.open(button_nama("button_masuk.png")), size=(147.29, 53.97))
    button_2 = ctk.CTkButton(
        window2,
        image=button_masuk_img,
        width=147.29,
        height=53.97,
        border_width=0,
        corner_radius=0,
        bg_color="#48775D",
        fg_color="#48775D",
        hover_color="#48775D",
        command=on_button_click,
        text=''
    )
    button_2.place(x=1100.0, y=665.0)

    window2.mainloop()

def halaman_awal():
    window = ctk.CTk()
    window.title("WARPAT!")
    window.geometry('1920x1200')
    window.state('zoomed')
    window.configure(bg="#fbcd64")
    window.resizable(True, True)

    bg_welcome = ImageTk.PhotoImage(Image.open("assets/background_welcome.png"))
    bgr = ctk.CTkLabel(master=window, image=bg_welcome, text="", width=1366, height=768)
    bgr.pack()

    def button_welcome(path: str) -> Path:
        return ASSETS_PATH / Path(path)

    button_start_image = ctk.CTkImage(Image.open(button_welcome("button_logo.png")), size=(250, 250))
    button_1 = ctk.CTkButton(
        window,
        image=button_start_image,
        width=200,
        height=200,
        corner_radius=0,
        bg_color="#fbcd64",
        fg_color="transparent",
        hover_color="#fbcd64",
        command=lambda: [window.destroy(), halaman_nama()],
        border_width=0,
        text=''
    )
    button_1.place(x=515.0, y=230.0)

    window.mainloop()

halaman_awal()
