import csv

def baca_menu(nama_file):
    menu = {}
    try:
        with open(nama_file, mode='r', newline='') as file:
            csv_reader = csv.DictReader(file)
            for baris in csv_reader:
                nama = baris['Nama']
                harga = int(baris['Harga'])
                menu[nama] = harga
    except FileNotFoundError:
        print(f"File {nama_file} tidak ditemukan.")
    except Exception as e:
        print(f"Terjadi kesalahan: {e}")
    return menu

def tampilkan_menu(menu):
    print("Daftar Menu:")
    for nama, harga in menu.items():
        print(f"{nama}: Rp{harga}")

def hitung_total_harga(menu, pilihan_pengguna):
    total = 0
    for pilihan in pilihan_pengguna:
        if pilihan in menu:
            total += menu[pilihan]
        else:
            print(f"Item {pilihan} tidak ada dalam menu.")
    return total

def main():
    nama_file = 'menu_minuman.csv'
    menu = baca_menu(nama_file)
    
    if not menu:
        return
    
    tampilkan_menu(menu)
    
    pilihan_pengguna = []
    while True:
        pilihan = input("Masukkan nama item yang ingin Anda pilih (atau ketik 'selesai' untuk mengakhiri): ").strip()
        if pilihan.lower() == 'selesai':
            break
        pilihan_pengguna.append(pilihan)
    
    total_harga = hitung_total_harga(menu, pilihan_pengguna)
    print(f"Total harga: Rp{total_harga}")

if __name__ == "__main__":
    main()
