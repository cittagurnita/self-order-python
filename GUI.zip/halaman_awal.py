from pathlib import Path
from tkinter import *
import tkinter as tk
from tkinter import Button, PhotoImage

OUTPUT_PATH = Path(__file__).parent
ASSETS_PATH = OUTPUT_PATH / Path(r"D:\SELF ORDER MACHINE\assets")

def menu_list():
    window3 = tk.Tk()
    window3.title("WARPAT!")
    window3.geometry('1200x675')
    window3.configure(bg="#FFFFFF")
    window3.resizable(True,True)

    frame = Frame(window3, width=1200, height=410, bg='#48775d')
    frame.place(x=0, y=600)

    frame = Frame(window3, width=1200, height=850, bg='#fbcd64')
    frame.place(x=0, y=-250)
    
    frame = Frame(window3, width=1200, height=370, bg='#c7411e')
    frame.place(x=0, y=-300)

def dine_option():
    window2 = tk.Tk()
    window2.title("WARPAT!")
    window2.geometry('1200x675')
    window2.configure(bg="#FFFFFF")
    window2.resizable(True,True)

    frame = Frame(window2, width=1200, height=410, bg='#48775d')
    frame.place(x=0, y=600)

    frame = Frame(window2, width=1200, height=850, bg='#fbcd64')
    frame.place(x=0, y=-250)
    
    frame = Frame(window2, width=1200, height=370, bg='#c7411e')
    frame.place(x=0, y=-300)

    heading = Label(window2, text="Pilih Penyajian", fg="#000000", bg="#fbcd64", font=("Monserrat",40,"bold"))
    heading.place(x=470, y=200)

    def button_dine(path: str) -> Path:
        return ASSETS_PATH / Path(path)

    button_image_2 = PhotoImage(file=button_dine("button_dine_in.png"))
    button_2 = Button(
        window2,
        image=button_image_2,
        borderwidth=0,
        bg="#fbcd64",
        highlightthickness=0,
        command=lambda: [window2.destroy, menu_list()],
        relief="flat"
    )
    button_2.place(x=470.0, y=280.0, width=190.0, height=185.0)

    button_image_3 = PhotoImage(file=button_dine("button_take_away.png"))
    button_3 = Button(
        window2,
        image=button_image_3,
        borderwidth=0,
        bg="#fbcd64",
        highlightthickness=0,
        command=lambda: [window2.destroy(), menu_list()],
        relief="flat"
    )
    button_3.place(x=680.0, y=280.0, width=190.0, height=185.0)

    window2.mainloop()

def halaman_awal():
    window = tk.Tk()
    window.title("WARPAT!")
    window.geometry('1200x675')
    window.configure(bg="#FFFFFF")
    window.resizable(True,True)

    frame = Frame(window, width=1200, height=410, bg='#48775d')
    frame.place(x=0, y=600)

    frame = Frame(window, width=1200, height=850, bg='#fbcd64')
    frame.place(x=0, y=-250)
    
    frame = Frame(window, width=1200, height=370, bg='#c7411e')
    frame.place(x=0, y=-300)
    
    heading = Label(window, text="Selamat Datang", fg="#000000", bg="#fbcd64", font=("Monserrat",40,"bold"))
    heading.place(x=390, y=200)
    
    heading = Label(window, text="di", fg="#000000", bg="#fbcd64", font=("Monserrat",40,"bold"))
    heading.place(x=560, y=260)
    
    heading = Label(window, text="WARPAT!", fg="#000000", bg="#fbcd64", font=("Monserrat",40,"bold"))
    heading.place(x=460, y=330)

    def button_start(path: str) -> Path:
        return ASSETS_PATH / Path(path)

    button_image_1 = PhotoImage(file=button_start("button_1.png"))
    button_1 = Button(
        window,
        image=button_image_1,
        borderwidth=0,
        bg="#fbcd64",
        highlightthickness=0,
        command=lambda: [window.destroy(), dine_option()],
        relief="flat"
    )
    button_1.place(x=520.0, y=420.0, width=110.0, height=35.0)

    window.mainloop()

halaman_awal()

