import csv
import customtkinter as ctk
from tkinter import ttk

# Membaca data dari file CSV
def baca_csv(file_path):
    data = []
    with open(file_path, newline='', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            data.append(row)
    return data

# Fungsi untuk membuat label makanan
def buat_label(frame, text, row, col):
    label = ctk.CTkLabel(master=frame, text=text)
    label.grid(row=row, column=col, padx=10, pady=5, sticky="w")
    return label

root = ctk.CTk()
root.title("Daftar Minuman")
root.geometry("400x300")

main_frame = ctk.CTkFrame(master=root)
main_frame.pack(fill="both", expand=True, padx=10, pady=10)

canvas = ctk.CTkCanvas(master=main_frame)
canvas.pack(side="left", fill="both", expand=True)

scrollbar = ttk.Scrollbar(master=main_frame, orient="vertical", command=canvas.yview)
scrollbar.pack(side="right", fill="y")

scrollable_frame = ctk.CTkFrame(master=canvas)

scrollable_frame.bind(
    "<Configure>",
    lambda e: canvas.configure(
        scrollregion=canvas.bbox("all")
    )
)

canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")

canvas.configure(yscrollcommand=scrollbar.set)